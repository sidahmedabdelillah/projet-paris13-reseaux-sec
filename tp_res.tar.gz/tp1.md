# Routage Static

## Connection entre un routeur et un PC

On Concider la topology ce desous:

![topology1](./img/tp1/topo1.png)

1. Nommer le routeur:

```js
Router>en
Router#conf t
Enter configuration commands, one per line.  End with CNTL/Z.
Router(config)#hos
Router(config)#hostname Rx
Rx(config)#
```

2. Activation de l'interface GE0/0/0/

```js
Rx(config)#interface gigabitEthernet 0/0/0
Rx(config-if)#ip address 192.168.1.254 255.255.255.0
Rx(config-if)#no shutdown
Rx(config-if)#exit
Rx(config)#exit
```

3. Reponse au question:

   - Proposition d'une configuration pour le PC:
     - addresse ip: 192.168.1.1
     - mask: 255.255.255.0 (/24)
     - address gatewat: 192.168.1.254

   - Verification de l'etat de l'interface GE0/0/0

```js
Rx# sh ip interface brief 
Interface            IP-Address    OK? Method Status           Protocol 
GigabitEthernet0/0/0 192.168.1.254 YES manual up     up 
GigabitEthernet0/0/1 unassigned    YES unset  administratively down down 
GigabitEthernet0/0/2 unassigned    YES unset  administratively down down 
Vlan1                unassigned    YES unset  administratively down down
```

- Test de la connectivite entre le routeur et le PC

```js
C:\>ping 192.168.1.254

Pinging 192.168.1.254 with 32 bytes of data:

Reply from 192.168.1.254: bytes=32 time<1ms TTL=255
Reply from 192.168.1.254: bytes=32 time<1ms TTL=255

Ping statistics for 192.168.1.254:
    Packets: Sent = 2, Received = 2, Lost = 0 (0% loss),
Approximate round trip times in milli-seconds:
    Minimum = 0ms, Maximum = 0ms, Average = 0ms

Control-C
```

- Sauvgarde de la configuration 

```js
Rx#sh startup-config 
startup-config is not present
Rx#copy running-config st
Rx#copy running-config startup-config 
Destination filename [startup-config]? 
Building configuration...
[OK]
Rx#sh start
Rx#sh startup-config 
Using 657 bytes
!
version 16.6.4
no service timestamps log datetime msec
no service timestamps debug datetime msec
no service password-encryption
!
hostname Rx
!
!
!
!
!
!
!
!
ip cef
no ipv6 cef
!
!
!
```

Avant qu'on a copie la configuration de routeur vers la configuration initial ("startup-config"), on a verfie qu'il'nya pas de configuration enregister comme une configuration de startup. Apres le copiage on a verifier qu'il existe un configuration enregister comme un 